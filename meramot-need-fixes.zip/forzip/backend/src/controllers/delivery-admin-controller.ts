import { Request, Response } from "express";
import prisma from "../models/prisma.js";
import { getPusherPublicConfig, publishDeliveryChatMessage } from "../services/pusher-service.js";

export async function getDeliveryAdminStats(_req: Request, res: Response) {
  try {
    const [
      activeApprovedPartners,
      totalPartners,
      completedDeliveriesTotal,
    ] = await Promise.all([
      prisma.user.count({
        where: { role: "DELIVERY", status: "ACTIVE" },
      }),
      prisma.user.count({ where: { role: "DELIVERY" } }),
      prisma.delivery.count({ where: { status: "DELIVERED" } }),
    ]);

    const partnersWithCompleted = await prisma.delivery.findMany({
      where: {
        status: "DELIVERED",
        deliveryAgentId: { not: null },
      },
      select: {
        deliveryAgent: {
          select: {
            userId: true,
          },
        },
      },
    });

    const partnerUserIds = (partnersWithCompleted as Array<{ deliveryAgent: { userId: string } | null }>)
      .map((row: { deliveryAgent: { userId: string } | null }) => row.deliveryAgent?.userId)
      .filter((id: string | undefined): id is string => Boolean(id));

    const partnersCompletedAtLeastOne = new Set(partnerUserIds).size;

    return res.json({
      stats: {
        pendingRegistrations: 0,
        activeApprovedPartners,
        rejectedPartners: 0,
        totalPartners,
        completedDeliveriesTotal,
        partnersWithCompletedDeliveries: partnersCompletedAtLeastOne,
      },
    });
  } catch (error) {
    console.error("getDeliveryAdminStats error:", error);
    return res.status(500).json({ message: "Server error" });
  }
}

export async function listDeliveryPartners(req: Request, res: Response) {
  try {
    const rawRegistrationStatus =
      typeof req.query.registrationStatus === "string"
        ? req.query.registrationStatus.trim().toUpperCase()
        : "";
    const allowedRegistrationStatuses = new Set(["PENDING", "APPROVED", "REJECTED"]);
    const registrationStatusFilter = allowedRegistrationStatuses.has(rawRegistrationStatus)
      ? rawRegistrationStatus
      : "";

    const partners = await prisma.user.findMany({
      where: { role: "DELIVERY" },
      orderBy: { updatedAt: "desc" },
      take: 200,
    });

    const ids = (partners as Array<{ id: string }>).map((p: { id: string }) => p.id);
    const completedByRider =
      ids.length === 0
        ? []
        : await prisma.delivery.findMany({
            where: {
              status: "DELIVERED",
              deliveryAgent: {
                is: {
                  userId: { in: ids },
                },
              },
            },
            select: {
              deliveryAgent: {
                select: {
                  userId: true,
                },
              },
            },
          });

    const completedMap = (completedByRider as Array<{ deliveryAgent: { userId: string } | null }>).reduce<
      Map<string, number>
    >((acc: Map<string, number>, row: { deliveryAgent: { userId: string } | null }) => {
      const userId = row.deliveryAgent?.userId;
      if (!userId) return acc;
      acc.set(userId, (acc.get(userId) ?? 0) + 1);
      return acc;
    }, new Map());

    const riderProfiles = ids.length
      ? await prisma.riderProfile.findMany({
          where: { userId: { in: ids } },
          select: {
            id: true,
            userId: true,
          },
        })
      : [];

    const riderProfileByUserId = new Map<string, string>(
      riderProfiles.map((profile: { userId: string; id: string }) => [profile.userId, profile.id]),
    );

    const activeDeliveries = riderProfiles.length
      ? await prisma.delivery.findMany({
          where: {
            deliveryAgentId: {
              in: riderProfiles.map((profile: { id: string }) => profile.id),
            },
            status: {
              in: ["SCHEDULED", "DISPATCHED", "PICKED_UP", "IN_TRANSIT"],
            },
          },
          orderBy: { updatedAt: "desc" },
          select: {
            id: true,
            status: true,
            direction: true,
            pickupAddress: true,
            dropAddress: true,
            updatedAt: true,
            deliveryAgentId: true,
          },
        })
      : [];

    const activeDeliveryByRiderProfileId = new Map<string, (typeof activeDeliveries)[number]>();
    for (const delivery of activeDeliveries) {
      if (!delivery.deliveryAgentId) continue;
      if (!activeDeliveryByRiderProfileId.has(delivery.deliveryAgentId)) {
        activeDeliveryByRiderProfileId.set(delivery.deliveryAgentId, delivery);
      }
    }

    const rows = (partners as Array<any>)
      .map((p: any) => {
        const registrationStatus =
          p.status === "ACTIVE" ? "APPROVED" : p.status === "SUSPENDED" ? "REJECTED" : "PENDING";
        const riderProfileId = riderProfileByUserId.get(p.id);
        const activeDelivery = riderProfileId
          ? activeDeliveryByRiderProfileId.get(riderProfileId) ?? null
          : null;

        return {
          id: p.id,
          vehicleType: "BIKE", // Default since it was removed from schema
          nidDocumentUrl: null,
          educationDocumentUrl: null,
          cvDocumentUrl: null,
          agentStatus: p.status,
          isActive: p.status === "ACTIVE",
          registrationStatus,
          currentLat: p.lat,
          currentLng: p.lng,
          createdAt: p.createdAt,
          updatedAt: p.updatedAt,
          user: p,
          completedDeliveries: completedMap.get(p.id) ?? 0,
          activeDelivery,
        };
      })
      .filter((row) => (registrationStatusFilter ? row.registrationStatus === registrationStatusFilter : true));

    return res.json({ partners: rows });
  } catch (error) {
    console.error("listDeliveryPartners error:", error);
    return res.status(500).json({ message: "Server error" });
  }
}

export async function listDeliveryOrders(req: Request, res: Response) {
  try {
    const rawStatus = typeof req.query.status === "string" ? req.query.status.trim().toUpperCase() : "";
    const allowedStatuses = new Set([
      "PENDING",
      "SCHEDULED",
      "DISPATCHED",
      "PICKED_UP",
      "IN_TRANSIT",
      "DELIVERED",
      "FAILED",
      "CANCELLED",
    ]);
    const statusFilter = allowedStatuses.has(rawStatus) ? rawStatus : undefined;

    const deliveries = await prisma.delivery.findMany({
      where: {
        ...(statusFilter ? { status: statusFilter } : {}),
      },
      include: {
        repairJob: {
          include: {
            repairRequest: {
              select: {
                id: true,
                title: true,
                deviceType: true,
                status: true,
                contactPhone: true,
                user: {
                  select: {
                    id: true,
                    name: true,
                    username: true,
                    phone: true,
                  },
                },
              },
            },
            shop: {
              select: {
                id: true,
                name: true,
                phone: true,
                address: true,
              },
            },
          },
        },
        deliveryAgent: {
          include: {
            user: {
              select: {
                id: true,
                name: true,
                username: true,
                email: true,
                phone: true,
                lat: true,
                lng: true,
                status: true,
              },
            },
          },
        },
      },
      orderBy: { updatedAt: "desc" },
      take: 300,
    });

    return res.json({ deliveries });
  } catch (error) {
    console.error("listDeliveryOrders error:", error);
    return res.status(500).json({ message: "Server error" });
  }
}

export async function assignDeliveryOrder(req: Request, res: Response) {
  try {
    const rawDeliveryId = (req.params as { id?: unknown }).id;
    const { deliveryUserId } = req.body as { deliveryUserId?: unknown };
    if (typeof rawDeliveryId !== "string" || !rawDeliveryId.trim()) {
      return res.status(400).json({ message: "Delivery id is required" });
    }
    if (typeof deliveryUserId !== "string" || !deliveryUserId.trim()) {
      return res.status(400).json({ message: "deliveryUserId is required" });
    }

    const deliveryId = rawDeliveryId.trim();
    const partnerUserId = deliveryUserId.trim();

    const partner = await prisma.user.findUnique({
      where: { id: partnerUserId },
      select: { id: true, role: true, status: true, name: true, phone: true },
    });
    if (!partner || partner.role !== "DELIVERY") {
      return res.status(404).json({ message: "Delivery agent not found" });
    }
    if (partner.status !== "ACTIVE") {
      return res.status(400).json({ message: "Delivery agent must be active" });
    }

    let riderProfile = await prisma.riderProfile.findUnique({
      where: { userId: partnerUserId },
      select: { id: true },
    });
    if (!riderProfile) {
      riderProfile = await prisma.riderProfile.create({
        data: {
          userId: partnerUserId,
          registrationStatus: "APPROVED",
          isActive: true,
          status: "AVAILABLE",
        },
        select: { id: true },
      });
    }

    const activeDelivery = await prisma.delivery.findFirst({
      where: {
        deliveryAgentId: riderProfile.id,
        status: { in: ["SCHEDULED", "DISPATCHED", "PICKED_UP", "IN_TRANSIT"] },
      },
      select: { id: true },
    });
    if (activeDelivery) {
      return res
        .status(409)
        .json({ message: "Delivery agent already has an active delivery in progress" });
    }

    const now = new Date();
    const updated = await prisma.delivery.update({
      where: { id: deliveryId },
      data: {
        deliveryAgentId: riderProfile.id,
        riderName: partner.name ?? null,
        riderPhone: partner.phone ?? null,
        status: "SCHEDULED",
        scheduledAt: now,
      },
      include: {
        repairJob: {
          include: {
            repairRequest: {
              select: {
                id: true,
                title: true,
                deviceType: true,
                status: true,
                contactPhone: true,
              },
            },
            shop: {
              select: {
                id: true,
                name: true,
                phone: true,
                address: true,
              },
            },
          },
        },
        deliveryAgent: {
          include: {
            user: {
              select: {
                id: true,
                name: true,
                username: true,
                email: true,
                phone: true,
              },
            },
          },
        },
      },
    });

    return res.json({
      message: "Delivery assigned successfully",
      delivery: updated,
    });
  } catch (error) {
    console.error("assignDeliveryOrder error:", error);
    return res.status(500).json({ message: "Server error" });
  }
}

export async function getDeliveryOrderTimeline(req: Request, res: Response) {
  try {
    const rawDeliveryId = (req.params as { id?: unknown }).id;
    if (typeof rawDeliveryId !== "string" || !rawDeliveryId.trim()) {
      return res.status(400).json({ message: "Delivery id is required" });
    }
    const deliveryId = rawDeliveryId.trim();

    const delivery = await prisma.delivery.findUnique({
      where: { id: deliveryId },
      include: {
        repairJob: {
          include: {
            repairRequest: {
              select: {
                id: true,
                title: true,
                deviceType: true,
              },
            },
            shop: {
              select: {
                id: true,
                name: true,
              },
            },
          },
        },
        deliveryAgent: {
          include: {
            user: {
              select: {
                id: true,
                name: true,
                username: true,
                phone: true,
                lat: true,
                lng: true,
              },
            },
          },
        },
      },
    });

    if (!delivery) {
      return res.status(404).json({ message: "Delivery not found" });
    }

    const timeline = [
      { code: "CREATED", title: "Order created", at: delivery.createdAt },
      { code: "SCHEDULED", title: "Assigned to rider", at: delivery.scheduledAt },
      { code: "PICKED_UP", title: "Picked up by rider", at: delivery.pickedUpAt },
      { code: "DELIVERED", title: "Delivered", at: delivery.deliveredAt },
      { code: "LAST_UPDATE", title: "Last updated", at: delivery.updatedAt },
    ];

    return res.json({
      delivery,
      timeline,
      pusher: getPusherPublicConfig(),
    });
  } catch (error) {
    console.error("getDeliveryOrderTimeline error:", error);
    return res.status(500).json({ message: "Server error" });
  }
}

export async function getAdminDeliveryChatMessages(req: Request, res: Response) {
  try {
    const rawDeliveryId = (req.params as { id?: unknown }).id;
    if (typeof rawDeliveryId !== "string" || !rawDeliveryId.trim()) {
      return res.status(400).json({ message: "Delivery id is required" });
    }
    const deliveryId = rawDeliveryId.trim();

    const messages = await prisma.deliveryChatMessage.findMany({
      where: { deliveryId },
      orderBy: { createdAt: "asc" },
      take: 200,
    });

    return res.json({
      messages,
      pusher: getPusherPublicConfig(),
    });
  } catch (error) {
    console.error("getAdminDeliveryChatMessages error:", error);
    return res.status(500).json({ message: "Server error" });
  }
}

export async function sendAdminDeliveryChatMessage(req: Request, res: Response) {
  try {
    const adminUserId = req.deliveryAdminAuth?.userId;
    if (!adminUserId) {
      return res.status(401).json({ message: "Unauthorized" });
    }

    const rawDeliveryId = (req.params as { id?: unknown }).id;
    const { message } = req.body as { message?: unknown };
    if (typeof rawDeliveryId !== "string" || !rawDeliveryId.trim()) {
      return res.status(400).json({ message: "Delivery id is required" });
    }
    if (typeof message !== "string" || !message.trim()) {
      return res.status(400).json({ message: "Message is required" });
    }
    const deliveryId = rawDeliveryId.trim();

    const delivery = await prisma.delivery.findUnique({
      where: { id: deliveryId },
      include: {
        deliveryAgent: {
          select: {
            userId: true,
          },
        },
      },
    });
    if (!delivery) {
      return res.status(404).json({ message: "Delivery not found" });
    }
    if (!delivery.deliveryAgent?.userId) {
      return res.status(400).json({ message: "No delivery agent assigned for this order" });
    }

    const created = await prisma.deliveryChatMessage.create({
      data: {
        deliveryId,
        senderUserId: adminUserId,
        senderRole: "DELIVERY_ADMIN",
        recipientUserId: delivery.deliveryAgent.userId,
        message: message.trim(),
      },
    });

    await publishDeliveryChatMessage(deliveryId, created);

    return res.status(201).json({ message: created });
  } catch (error) {
    console.error("sendAdminDeliveryChatMessage error:", error);
    return res.status(500).json({ message: "Server error" });
  }
}

export async function approveDeliveryPartner(req: Request, res: Response) {
  // Legacy function: RiderProfiles are no longer in schema. We just set user to active.
  try {
    const rawId = (req.params as { id?: unknown }).id;
    if (typeof rawId !== "string" || !rawId.trim()) {
      return res.status(400).json({ message: "Partner id is required" });
    }

    const partnerId = rawId.trim();

    const updated = await prisma.user.update({
      where: { id: partnerId },
      data: { status: "ACTIVE" },
    });

    return res.json({
      message: "Delivery partner activated",
      partner: updated,
    });
  } catch (error) {
    console.error("approveDeliveryPartner error:", error);
    return res.status(500).json({ message: "Server error" });
  }
}

export async function rejectDeliveryPartner(req: Request, res: Response) {
  try {
    const rawId = (req.params as { id?: unknown }).id;
    if (typeof rawId !== "string" || !rawId.trim()) {
      return res.status(400).json({ message: "Partner id is required" });
    }

    const updated = await prisma.user.update({
      where: { id: rawId.trim() },
      data: { status: "SUSPENDED" },
    });

    return res.json({
      message: "Delivery partner suspended",
      partner: updated,
    });
  } catch (error) {
    console.error("rejectDeliveryPartner error:", error);
    return res.status(500).json({ message: "Server error" });
  }
}

export async function listDeliveryPayoutRequests(req: Request, res: Response) {
  try {
    const allowedStatuses = ["PENDING", "PROCESSING", "PAID", "FAILED", "CANCELLED"] as const;
    type PayoutStatusValue = (typeof allowedStatuses)[number];
    const rawStatus = typeof req.query.status === "string" ? req.query.status.trim().toUpperCase() : "";
    const statusFilter =
      rawStatus && (allowedStatuses as readonly string[]).includes(rawStatus)
        ? (rawStatus as PayoutStatusValue)
        : undefined;

    const payouts = await prisma.vendorPayout.findMany({
      where: {
        riderProfileId: { not: null },
        ...(statusFilter ? { status: statusFilter } : {}),
      },
      include: {
        riderProfile: {
          include: {
            user: {
              select: {
                id: true,
                name: true,
                username: true,
                email: true,
                phone: true,
              },
            },
          },
        },
      },
      orderBy: { createdAt: "desc" },
      take: 100,
    });

    return res.json({ payouts });
  } catch (error) {
    console.error("listDeliveryPayoutRequests error:", error);
    return res.status(500).json({ message: "Server error" });
  }
}

export async function approveDeliveryPayoutRequest(req: Request, res: Response) {
  try {
    const rawId = (req.params as { id?: unknown }).id;
    if (typeof rawId !== "string" || !rawId.trim()) {
      return res.status(400).json({ message: "Payout request id is required" });
    }
    const payoutId = rawId.trim();

    const existing = await prisma.vendorPayout.findUnique({
      where: { id: payoutId },
      select: {
        id: true,
        riderProfileId: true,
        status: true,
      },
    });

    if (!existing || !existing.riderProfileId) {
      return res.status(404).json({ message: "Payout request not found" });
    }
    if (existing.status !== "PENDING" && existing.status !== "PROCESSING") {
      return res.status(409).json({ message: "Only pending payout requests can be approved" });
    }

    const updated = await prisma.vendorPayout.update({
      where: { id: payoutId },
      data: {
        status: "PAID",
        paidAt: new Date(),
      },
      include: {
        riderProfile: {
          include: {
            user: {
              select: {
                id: true,
                name: true,
                username: true,
                email: true,
              },
            },
          },
        },
      },
    });

    return res.json({
      message: "Payout approved successfully",
      payout: updated,
    });
  } catch (error) {
    console.error("approveDeliveryPayoutRequest error:", error);
    return res.status(500).json({ message: "Server error" });
  }
}
